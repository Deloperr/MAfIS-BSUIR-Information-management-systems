package com.example.smsreceiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast

class SmsBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("SmsBroadcastReceiver", "=== BROADCAST RECEIVED IN SEPARATE CLASS ===")
        Log.d("SmsBroadcastReceiver", "Action: ${intent.action}")
        Log.d("SmsBroadcastReceiver", "Extras: ${intent.extras}")

        when (intent.action) {
            "com.example.ACTION_SEND_SMS" -> {
                val phoneNumber = intent.getStringExtra("phone_number")
                val message = intent.getStringExtra("message")

                Log.d("SmsBroadcastReceiver", "Phone: $phoneNumber, Message: $message")

                if (!phoneNumber.isNullOrEmpty() && !message.isNullOrEmpty()) {
                    val serviceIntent = Intent(context, SmsService::class.java).apply {
                        putExtra("phone_number", phoneNumber)
                        putExtra("message", message)
                    }
                    context.startService(serviceIntent)

                    Toast.makeText(context, "SMS Broadcast received, starting service...",
                        Toast.LENGTH_LONG).show()
                    Log.i("SmsBroadcastReceiver", "SMS service started via separate receiver class")

                    sendStatusBroadcast(context, "SMS processing for: $phoneNumber")
                } else {
                    Toast.makeText(context, "Invalid broadcast data", Toast.LENGTH_LONG).show()
                    Log.e("SmsBroadcastReceiver", "Invalid phone or message in broadcast")
                    sendStatusBroadcast(context, "Error: Invalid broadcast data")
                }
            }
            else -> {
                Log.d("SmsBroadcastReceiver", "Unknown action: ${intent.action}")
            }
        }
    }

    private fun sendStatusBroadcast(context: Context, status: String) {
        val broadcastIntent = Intent("com.example.ACTION_SMS_STATUS").apply {
            putExtra("status", status)
            setPackage("com.example.broadcastsender") // Явно указываем пакет отправителя
        }
        context.sendBroadcast(broadcastIntent)
        Log.d("SmsBroadcastReceiver", "Status broadcast sent: $status")
    }
}