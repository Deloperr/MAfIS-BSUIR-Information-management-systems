package com.example.smsreceiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.Manifest
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var buttonStart: Button
    private lateinit var buttonStop: Button
    private lateinit var tvStatus: TextView

    private lateinit var smsBroadcastReceiver: SmsBroadcastReceiver
    private val SMS_PERMISSION_CODE = 123

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupClickListeners()
        setupDynamicReceiver()
        requestSmsPermissions()
    }

    override fun onResume() {
        super.onResume()
        registerSmsReceiver()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(smsBroadcastReceiver)
    }

    private fun initializeViews() {
        buttonStart = findViewById(R.id.buttonStart)
        buttonStop = findViewById(R.id.buttonStop)
        tvStatus = findViewById(R.id.tvStatus)
    }

    private fun setupClickListeners() {
        buttonStart.setOnClickListener {
            if (hasAllPermissions()) {
                startService(Intent(this, SmsService::class.java))
                Toast.makeText(this, "SMS Service Started", Toast.LENGTH_LONG).show()
                updateStatus("✅ SMS Service Started\n📱 Waiting for broadcasts...")
                Log.d("SMSReceiver", "SMS Service started")
            } else {
                requestSmsPermissions()
            }
        }

        buttonStop.setOnClickListener {
            stopService(Intent(this, SmsService::class.java))
            Toast.makeText(this, "SMS Service Stopped", Toast.LENGTH_LONG).show()
            updateStatus("❌ SMS Service Stopped")
            Log.d("SMSReceiver", "SMS Service stopped")
        }
    }

    private fun setupDynamicReceiver() {
        smsBroadcastReceiver = SmsBroadcastReceiver()
        Log.d("SMSReceiver", "SmsBroadcastReceiver instance created")
    }

    private fun registerSmsReceiver() {
        val filter = IntentFilter().apply {
            addAction("com.example.ACTION_SEND_SMS")
        }
        registerReceiver(smsBroadcastReceiver, filter)

        Log.d("SMSReceiver", "SmsBroadcastReceiver dynamically registered")
        updateStatus("✅ Dynamic Receiver Registered\n📱 Waiting for broadcasts...")
        Toast.makeText(this, "SMS Broadcast Receiver Ready", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus(status: String) {
        tvStatus.text = status
        Log.d("SMSReceiver", "Status updated: $status")
    }

    private fun hasAllPermissions(): Boolean {
        return arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        ).all { permission ->
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestSmsPermissions() {
        val permissions = arrayOf(
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE
        )

        ActivityCompat.requestPermissions(this, permissions, SMS_PERMISSION_CODE)
        Log.d("SMSReceiver", "Requesting SMS permissions")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            SMS_PERMISSION_CODE -> {
                val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                if (allGranted) {
                    Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show()
                    updateStatus("✅ All Permissions Granted\n✅ Service Ready\n📱 Waiting for broadcasts...")
                    Log.i("SMSReceiver", "All SMS permissions granted")
                } else {
                    Toast.makeText(this, "Some permissions denied", Toast.LENGTH_SHORT).show()
                    updateStatus("❌ Some Permissions Denied\n⚠️ SMS may not work")
                    Log.w("SMSReceiver", "Some SMS permissions denied")
                }
            }
        }
    }
}