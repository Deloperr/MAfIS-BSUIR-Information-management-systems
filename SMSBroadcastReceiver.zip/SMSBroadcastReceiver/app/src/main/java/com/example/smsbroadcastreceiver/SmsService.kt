package com.example.smsreceiver

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.telephony.SmsManager
import android.widget.Toast
import android.util.Log
import android.Manifest
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager

class SmsService : Service() {

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Toast.makeText(this, "SMS Service Created", Toast.LENGTH_LONG).show()
        Log.d("SmsService", "Service Created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("SmsService", "Service Started")

        intent?.let {
            val phoneNumber = it.getStringExtra("phone_number")
            val message = it.getStringExtra("message")

            if (!phoneNumber.isNullOrEmpty() && !message.isNullOrEmpty()) {
                sendSMS(phoneNumber, message)
            }
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Toast.makeText(this, "SMS Service Stopped", Toast.LENGTH_LONG).show()
        Log.d("SmsService", "Service Stopped")
    }

    private fun sendSMS(phoneNumber: String, message: String) {
        try {
            if (!hasSmsPermissions()) {
                Toast.makeText(this, "SMS permissions not granted", Toast.LENGTH_LONG).show()
                Log.e("SmsService", "SMS permissions not granted")
                return
            }

            val smsManager: SmsManager = SmsManager.getDefault()
            val formattedNumber = formatPhoneNumber(phoneNumber)

            smsManager.sendTextMessage(formattedNumber, null, message, null, null)

            val successMessage = "✅ SMS sent to: $formattedNumber"
            Toast.makeText(this, successMessage, Toast.LENGTH_LONG).show()
            Log.i("SmsService", successMessage)

            sendStatusBroadcast("SMS successfully sent to $formattedNumber")

        } catch (e: Exception) {
            val errorMessage = "❌ SMS sending failed: ${e.message}"
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            Log.e("SmsService", errorMessage, e)
            sendStatusBroadcast("SMS failed: ${e.message}")
        }
    }

    private fun hasSmsPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun formatPhoneNumber(phoneNumber: String): String {
        var formatted = phoneNumber.trim()
        formatted = formatted.replace("[^+0-9]".toRegex(), "")

        if (formatted.startsWith("8") && !formatted.startsWith("+")) {
            formatted = "+7" + formatted.substring(1)
        } else if (formatted.startsWith("7") && !formatted.startsWith("+")) {
            formatted = "+" + formatted
        } else if (formatted.length == 10 && formatted[0] in '0'..'9') {
            formatted = "+7$formatted"
        }

        return formatted
    }

    private fun sendStatusBroadcast(status: String) {
        val broadcastIntent = Intent("com.example.ACTION_SMS_STATUS").apply {
            putExtra("status", status)
            setPackage("com.example.broadcastsender")
        }
        sendBroadcast(broadcastIntent)
    }
}