package com.example.listviewapp

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import androidx.appcompat.widget.PopupMenu
import android.content.Intent
import android.net.Uri
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var imageView: ImageView
    private lateinit var toolbar: Toolbar
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentCountry: CountryData? = null

    private val countries = listOf(
        CountryData("USA", R.drawable.image1, R.raw.usa_anthem,
            R.anim.slide_in_left, R.anim.bounce),
        CountryData("Ukraine", R.drawable.image2, R.raw.ukraine_anthem,
            R.anim.slide_in_right, R.anim.rotate_scale),
        CountryData("England", R.drawable.image3, R.raw.england_anthem,
            R.anim.zoom_in, R.anim.zoom_in),
        CountryData("Kazakhstan", R.drawable.image4, R.raw.kazakhstan_anthem,
            R.anim.slide_up, R.anim.spin),
        CountryData("Belarus", R.drawable.image5, R.raw.belarus_anthem,
            R.anim.wobble, R.anim.shake),
        CountryData("Russia", R.drawable.image6, R.raw.russia_anthem,
            R.anim.pulse, R.anim.swing),
        CountryData("Germany", R.drawable.image7, R.raw.germany_anthem,
            R.anim.bounce_in, R.anim.rotate_3d),
        CountryData("Poland", R.drawable.image8, R.raw.poland_anthem,
            R.anim.fade_in_scale, R.anim.wave)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initializeViews()
        setupToolbar()
        setupListView()
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        listView = findViewById(R.id.list)
        imageView = findViewById(R.id.imageView1)

        imageView.setOnClickListener {
            showImagePopupMenu(it)
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Флаги Мира"
        supportActionBar?.subtitle = "Выберите страну"
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    private fun setupListView() {
        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_1,
            countries.map { it.name }
        ) {
            private val animatedPositions = mutableSetOf<Int>()

            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = convertView ?: super.getView(position, convertView, parent)

                if (!animatedPositions.contains(position)) {
                    animatedPositions.add(position)
                    view.alpha = 0f

                    handler.postDelayed({
                        val country = countries[position]
                        val listAnimation = AnimationUtils.loadAnimation(context, country.listAnimation)
                        view.startAnimation(listAnimation)
                        view.alpha = 1f
                    }, (position * 300).toLong())
                }

                return view
            }
        }

        listView.adapter = adapter

        listView.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, _ ->
                val country = countries[position]
                currentCountry = country
                supportActionBar?.subtitle = "Выбрано: ${country.name}"
                resetViewTransformations(view)
                imageView.setImageResource(country.imageRes)
                resetViewTransformations(imageView)
                val imageAnimation = AnimationUtils.loadAnimation(this, country.imageAnimation)
                imageView.startAnimation(imageAnimation)
                playAnthem(country.anthemRes)

                Toast.makeText(
                    this,
                    "Selected: ${country.name}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                showSettings()
                true
            }
            R.id.menu_about -> {
                showAbout()
                true
            }
            R.id.menu_search -> {
                showSearch()
                true
            }
            R.id.menu_help -> {
                showHelp()
                true
            }
            R.id.menu_reset -> {
                resetApp()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSettings() {
        Toast.makeText(this, "Открыть настройки", Toast.LENGTH_SHORT).show()
        val scaleX = ObjectAnimator.ofFloat(imageView, "scaleX", 1f, 1.1f, 1f)
        val scaleY = ObjectAnimator.ofFloat(imageView, "scaleY", 1f, 1.1f, 1f)
        val set = AnimatorSet()
        set.playTogether(scaleX, scaleY)
        set.duration = 300
        set.start()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("О приложении Флаги Мира")
            .setMessage("Приложение для изучения флагов стран мира\n\nВерсия 1.0")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSearch() {
        val editText = EditText(this)
        val alertDialog = AlertDialog.Builder(this)
            .setTitle("Поиск страны")
            .setMessage("Введите название страны:")
            .setView(editText)
            .setPositiveButton("Искать") { dialog: android.content.DialogInterface, which: Int ->
                val searchQuery = editText.text.toString()
                if (searchQuery.isNotEmpty()) {
                    searchCountry(searchQuery)
                } else {
                    Toast.makeText(this, "Введите название страны", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .create()

        alertDialog.show()
    }

    private fun searchCountry(query: String) {
        val foundCountry = countries.find { it.name.contains(query, ignoreCase = true) }
        if (foundCountry != null) {
            val position = countries.indexOf(foundCountry)
            listView.smoothScrollToPosition(position)
            listView.setSelection(position)
            Toast.makeText(this, "Найдена: ${foundCountry.name}", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Страна '$query' не найдена", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("Помощь")
            .setMessage("Как пользоваться приложением:\n\n1. Выберите страну из списка\n2. Наслаждайтесь анимацией флага\n3. Слушайте гимн страны\n4. Нажмите на флаг для дополнительных опций")
            .setPositiveButton("Понятно", null)
            .show()
    }

    private fun resetApp() {
        AlertDialog.Builder(this)
            .setTitle("Сброс приложения")
            .setMessage("Вы уверены, что хотите сбросить приложение?")
            .setPositiveButton("Сбросить") { dialog: android.content.DialogInterface, which: Int ->
                currentCountry = null
                mediaPlayer?.release()
                mediaPlayer = null
                imageView.setImageResource(R.drawable.ic_launcher_background)
                resetViewTransformations(imageView)
                supportActionBar?.subtitle = "Выберите страну"
                Toast.makeText(this, "Приложение сброшено", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showImagePopupMenu(view: View) {
        val popup = PopupMenu(this, view)
        popup.menuInflater.inflate(R.menu.image_menu, popup.menu)

        if (currentCountry == null) {
            popup.menu.findItem(R.id.menu_share).isVisible = false
            popup.menu.findItem(R.id.menu_save).isVisible = false
            popup.menu.findItem(R.id.menu_info).isVisible = false
        }

        if (mediaPlayer == null || !mediaPlayer!!.isPlaying) {
            popup.menu.findItem(R.id.menu_stop_music).isVisible = false
        }

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_share -> {
                    shareImage()
                    true
                }
                R.id.menu_save -> {
                    saveImage()
                    true
                }
                R.id.menu_info -> {
                    showCountryInfo()
                    true
                }
                R.id.menu_stop_music -> {
                    stopMusic()
                    true
                }
                else -> false
            }
        }

        popup.show()
    }

    private fun shareImage() {
        currentCountry?.let { country ->
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, "Флаг ${country.name}")
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "Поделиться флагом"))
        } ?: run {
            Toast.makeText(this, "Сначала выберите страну", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveImage() {
        currentCountry?.let { country ->
            Toast.makeText(this, "Флаг ${country.name} сохранен", Toast.LENGTH_SHORT).show()
        } ?: run {
            Toast.makeText(this, "Сначала выберите страну", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCountryInfo() {
        currentCountry?.let { country ->
            val infoText = when (country.name) {
                "USA" -> "США - федеративная республика в Северной Америке"
                "Ukraine" -> "Украина - государство в Восточной Европе"
                "England" -> "Англия - страна в составе Великобритании"
                "Kazakhstan" -> "Казахстан - государство в Центральной Азии"
                "Belarus" -> "Беларусь - государство в Восточной Европе"
                "Russia" -> "Россия - крупнейшее государство в мире"
                "Germany" -> "Германия - федеративное государство в Центральной Европе"
                "Poland" -> "Польша - государство в Центральной Европе"
                else -> "Информация о стране"
            }

            AlertDialog.Builder(this)
                .setTitle(country.name)
                .setMessage(infoText)
                .setPositiveButton("OK", null)
                .show()
        } ?: run {
            Toast.makeText(this, "Сначала выберите страну", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopMusic() {
        mediaPlayer?.release()
        mediaPlayer = null
        Toast.makeText(this, "Музыка остановлена", Toast.LENGTH_SHORT).show()
    }

    private fun resetViewTransformations(view: View) {
        view.clearAnimation()
        view.animate().cancel()

        view.scaleX = 1f
        view.scaleY = 1f
        view.alpha = 1f
        view.rotation = 0f
        view.translationX = 0f
        view.translationY = 0f
    }

    private fun playAnthem(anthemRes: Int) {
        mediaPlayer?.release()

        try {
            if (anthemRes != 0) {
                mediaPlayer = MediaPlayer.create(this, anthemRes)
                mediaPlayer?.setOnCompletionListener {
                    it.release()
                    mediaPlayer = null
                }
                mediaPlayer?.start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
    }

    data class CountryData(
        val name: String,
        val imageRes: Int,
        val anthemRes: Int,
        val listAnimation: Int,
        val imageAnimation: Int
    )
}
