package com.example.databaselab

data class Student(
    var id: Long = 0,
    var name: String = "",
    var age: Int = 0,
    var address: String = ""
)