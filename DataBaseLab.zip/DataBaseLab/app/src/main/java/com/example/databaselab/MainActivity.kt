package com.example.databaselab

import android.annotation.SuppressLint
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etAge: EditText
    private lateinit var etAddress: EditText
    private lateinit var etEditor: EditText
    private lateinit var lvStudents: ListView

    private lateinit var db: DatabaseHandler
    private var selectedStudentId: Long = -1
    private var studentsList: MutableList<Student> = mutableListOf()

    private val studentsUri: Uri = StudentsProvider.CONTENT_URI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        db = DatabaseHandler(this)
        checkDataPersistence()
        setupClickListeners()
        loadStudentsToListView()
    }

    private fun initializeViews() {
        etName = findViewById(R.id.etName)
        etAge = findViewById(R.id.etAge)
        etAddress = findViewById(R.id.etAddress)
        etEditor = findViewById(R.id.etEditor)
        lvStudents = findViewById(R.id.lvStudents)
    }

    private fun setupClickListeners() {
        findViewById<Button>(R.id.btnAdd).setOnClickListener { addStudent() }
        findViewById<Button>(R.id.btnUpdate).setOnClickListener { updateStudent() }
        findViewById<Button>(R.id.btnReadAll).setOnClickListener { readAllStudents() }
        findViewById<Button>(R.id.btnSelectAge).setOnClickListener { selectStudentsByAge() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearDatabase() }
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }

        findViewById<Button>(R.id.btnExport).setOnClickListener {
            exportToTxtViaContentProvider()
        }

        lvStudents.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            if (position < studentsList.size) {
                val student = studentsList[position]
                selectedStudentId = student.id
                etName.setText(student.name)
                etAge.setText(student.age.toString())
                etAddress.setText(student.address)
                showMessage("Выбран студент: ${student.name}")
            }
        }
    }

    // ОСНОВНОЙ МЕТОД: ЭКСПОРТ В TXT ЧЕРЕЗ CONTENT PROVIDER В DOWNLOADS
    @SuppressLint("Range", "SimpleDateFormat")
    private fun exportToTxtViaContentProvider() {
        try {
            // Шаг 1: Получаем данные через Content Provider
            val cursor: Cursor? = contentResolver.query(
                studentsUri,
                arrayOf("id", "name", "age", "address"),
                null,
                null,
                "name ASC"
            )

            if (cursor == null) {
                showMessage("❌ Ошибка: Content Provider не вернул данные")
                return
            }

            if (cursor.count == 0) {
                showMessage("📭 Нет данных для экспорта")
                cursor.close()
                return
            }

            // Шаг 2: Создаем файл в папке Downloads
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            val fileName = "students_database_$timeStamp.txt"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val exportFile = File(downloadsDir, fileName)

            var recordCount = 0

            // Шаг 3: Записываем данные в файл
            FileWriter(exportFile).use { writer ->
                // Заголовок файла
                writer.write("=== БАЗА ДАННЫХ СТУДЕНТОВ ===\n")
                writer.write("Экспорт через Content Provider\n")
                writer.write("Дата создания: ${SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(Date())}\n")
                writer.write("Content Provider: ${StudentsProvider.PROVIDER_NAME}\n")
                writer.write("=".repeat(50) + "\n\n")

                // Данные студентов
                if (cursor.moveToFirst()) {
                    do {
                        recordCount++
                        val id = cursor.getLong(cursor.getColumnIndex("id"))
                        val name = cursor.getString(cursor.getColumnIndex("name"))
                        val age = cursor.getInt(cursor.getColumnIndex("age"))
                        val address = cursor.getString(cursor.getColumnIndex("address")) ?: "Не указан"

                        writer.write("СТУДЕНТ #$recordCount\n")
                        writer.write("ID: $id\n")
                        writer.write("Имя: $name\n")
                        writer.write("Возраст: $age\n")
                        writer.write("Адрес: $address\n")
                        writer.write("-".repeat(30) + "\n\n")

                    } while (cursor.moveToNext())
                }

                // Футер файла
                writer.write("=".repeat(50) + "\n")
                writer.write("ВСЕГО СТУДЕНТОВ: $recordCount\n")
                writer.write("Файл сохранен в: ${exportFile.absolutePath}\n")
            }

            cursor.close()

            // Шаг 4: Показываем результат
            showMessage("✅ Экспорт завершен!\nФайл сохранен в Downloads\nСтудентов: $recordCount")

            // Шаг 5: Показываем информацию в приложении
            displayExportResults(fileName, recordCount, exportFile.absolutePath)

        } catch (e: SecurityException) {
            showMessage("❌ Ошибка доступа: Нет разрешения для записи в хранилище")
            etEditor.setText("ОШИБКА ДОСТУПА\nНужно разрешение на запись в хранилище")
            // Можно запросить разрешение здесь
        } catch (e: Exception) {
            showMessage("❌ Ошибка экспорта: ${e.message}")
            etEditor.setText("ОШИБКА ЭКСПОРТА\n${e.message}")
        }
    }

    // Альтернативный метод для Android 10+ (Scoped Storage)
    @SuppressLint("Range", "SimpleDateFormat")
    private fun exportToTxtViaContentProviderModern() {
        try {
            val cursor: Cursor? = contentResolver.query(
                studentsUri,
                arrayOf("id", "name", "age", "address"),
                null, null, "name ASC"
            )

            if (cursor == null || cursor.count == 0) {
                showMessage("Нет данных для экспорта")
                cursor?.close()
                return
            }

            // Для Android 10+ используем MediaStore
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            val fileName = "students_$timeStamp.txt"

            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }

            val resolver = contentResolver
            val uri = resolver.insert(android.provider.MediaStore.Files.getContentUri("external"), values)

            if (uri != null) {
                var recordCount = 0
                resolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.writer().use { writer ->
                        writer.write("=== ЭКСПОРТ БАЗЫ ДАННЫХ ===\n\n")

                        if (cursor.moveToFirst()) {
                            do {
                                recordCount++
                                val id = cursor.getLong(cursor.getColumnIndex("id"))
                                val name = cursor.getString(cursor.getColumnIndex("name"))
                                val age = cursor.getInt(cursor.getColumnIndex("age"))
                                val address = cursor.getString(cursor.getColumnIndex("address")) ?: "Не указан"

                                writer.write("$recordCount. $name\n")
                                writer.write("   Возраст: $age лет\n")
                                writer.write("   Адрес: $address\n")
                                writer.write("   ID: $id\n\n")
                            } while (cursor.moveToNext())
                        }

                        writer.write("Всего: $recordCount студентов\n")
                    }
                }

                cursor.close()
                showMessage("✅ Файл сохранен в Downloads\nСтудентов: $recordCount")
                displayExportResults(fileName, recordCount, "Downloads/$fileName")
            }

        } catch (e: Exception) {
            showMessage("❌ Ошибка: ${e.message}")
        }
    }

    private fun displayExportResults(fileName: String, recordCount: Int, filePath: String) {
        val resultText = """
            |✅ ЭКСПОРТ ЧЕРЕЗ CONTENT PROVIDER УСПЕШНО ВЫПОЛНЕН!
            |
            |📊 ИНФОРМАЦИЯ О ЭКСПОРТЕ:
            |├─ Файл: $fileName
            |├─ Студентов: $recordCount
            |├─ Расположение: $filePath
            |├─ Источник: Content Provider
            |└─ Дата: ${SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(Date())}
            |
            |📁 Файл сохранен в папке Downloads вашего устройства.
            |Вы можете найти его через файловый менеджер.
            |
            |📋 СОДЕРЖИМОЕ ФАЙЛА:
            |${"=".repeat(45)}
            |
        """.trimMargin()

        etEditor.setText(resultText)

        // Добавляем preview содержимого
        val cursor: Cursor? = contentResolver.query(
            studentsUri, arrayOf("id", "name", "age", "address"), null, null, "name ASC"
        )

        if (cursor != null && cursor.moveToFirst()) {
            var previewCount = 0
            do {
                previewCount++
                if (previewCount > 5) { // Показываем только первые 5 записей для preview
                    etEditor.append("\n... и еще ${recordCount - 5} записей\n")
                    break
                }

                val id = cursor.getLong(cursor.getColumnIndex("id"))
                val name = cursor.getString(cursor.getColumnIndex("name"))
                val age = cursor.getInt(cursor.getColumnIndex("age"))
                val address = cursor.getString(cursor.getColumnIndex("address")) ?: "Не указан"

                etEditor.append("\n$previewCount. $name (ID: $id)\n")
                etEditor.append("   Возраст: $age лет\n")
                etEditor.append("   Адрес: $address\n")
            } while (cursor.moveToNext())

            cursor.close()
        }

        etEditor.append("\n" + "=".repeat(45))
        etEditor.append("\nПолный файл содержит $recordCount записей")
    }

    // Остальные методы остаются без изменений
    private fun addStudent() {
        val name = etName.text.toString().trim()
        val ageText = etAge.text.toString().trim()
        val address = etAddress.text.toString().trim()

        if (name.isNotEmpty() && ageText.isNotEmpty()) {
            try {
                val age = ageText.toInt()
                if (age < 0 || age > 150) {
                    showMessage("Возраст должен быть от 0 до 150 лет")
                    return
                }

                val student = Student(name = name, age = age, address = address)
                val id = db.addStudent(student)

                if (id != -1L) {
                    clearInputFields()
                    showMessage("Студент '$name' успешно добавлен (ID: $id)")
                    loadStudentsToListView()
                }

            } catch (e: NumberFormatException) {
                showMessage("Некорректный возраст. Введите число")
            }
        } else {
            showMessage("Заполните имя и возраст")
        }
    }

    private fun updateStudent() {
        if (selectedStudentId != -1L) {
            val name = etName.text.toString().trim()
            val ageText = etAge.text.toString().trim()
            val address = etAddress.text.toString().trim()

            if (name.isNotEmpty() && ageText.isNotEmpty()) {
                try {
                    val age = ageText.toInt()
                    val student = Student(id = selectedStudentId, name = name, age = age, address = address)
                    val count = db.updateStudent(student)

                    if (count > 0) {
                        showMessage("Данные студента '$name' успешно обновлены")
                        clearInputFields()
                        selectedStudentId = -1
                        loadStudentsToListView()
                    }

                } catch (e: NumberFormatException) {
                    showMessage("Некорректный возраст. Введите число")
                }
            }
        } else {
            showMessage("Сначала выберите студента из списка")
        }
    }

    private fun readAllStudents() {
        val students = db.getAllStudents()
        displayStudents(students)
        loadStudentsToListView()
        showMessage("Показаны все студенты (${students.size} записей)")
    }

    private fun selectStudentsByAge() {
        val students = db.getStudentsOlderThan(20)
        displayStudents(students)
        loadStudentsWithAgeFilter(students)
        showMessage("Показаны студенты старше 20 лет (${students.size} записей)")
    }

    private fun clearDatabase() {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Подтверждение")
        builder.setMessage("Вы уверены, что хотите удалить ВСЕХ студентов из базы данных?")
        builder.setPositiveButton("Да") { _, _ ->
            db.deleteAllStudents()
            showMessage("База данных полностью очищена")
            etEditor.setText("База данных очищена")
            studentsList.clear()
            loadStudentsToListView()
            clearInputFields()
        }
        builder.setNegativeButton("Нет") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun displayStudents(students: List<Student>) {
        val stringBuilder = StringBuilder()
        if (students.isEmpty()) {
            stringBuilder.append("Нет данных о студентах\n")
        } else {
            stringBuilder.append("Всего студентов: ${students.size}\n\n")
            students.forEachIndexed { index, student ->
                stringBuilder.append("${index + 1}. ID: ${student.id}\n")
                stringBuilder.append("   Имя: ${student.name}\n")
                stringBuilder.append("   Возраст: ${student.age}\n")
                stringBuilder.append("   Адрес: ${student.address}\n")
                stringBuilder.append("--------------------\n")
            }
        }
        etEditor.setText(stringBuilder.toString())
    }

    private fun loadStudentsToListView() {
        try {
            studentsList.clear()
            studentsList.addAll(db.getAllStudents())

            if (studentsList.isEmpty()) {
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                    listOf("Нет студентов. Добавьте первого студента."))
                lvStudents.adapter = adapter
            } else {
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                    studentsList.map { "👤 ${it.name} (${it.age} лет)\n📍 ${it.address}" })
                lvStudents.adapter = adapter
            }

            displayStudents(studentsList)

        } catch (e: Exception) {
            showMessage("Ошибка загрузки данных: ${e.message}")
        }
    }

    private fun loadStudentsWithAgeFilter(students: List<Student>) {
        studentsList.clear()
        studentsList.addAll(students)

        if (students.isEmpty()) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                listOf("Нет студентов старше 20 лет"))
            lvStudents.adapter = adapter
        } else {
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
                studentsList.map { "👤 ${it.name} (${it.age} лет)\n📍 ${it.address}" })
            lvStudents.adapter = adapter
        }
    }

    private fun clearInputFields() {
        etName.text.clear()
        etAge.text.clear()
        etAddress.text.clear()
        selectedStudentId = -1
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun checkDataPersistence() {
        val studentsCount = db.getStudentsCount()
        if (studentsCount > 0) {
            showMessage("База данных загружена. Студентов: $studentsCount")
        }
    }
}