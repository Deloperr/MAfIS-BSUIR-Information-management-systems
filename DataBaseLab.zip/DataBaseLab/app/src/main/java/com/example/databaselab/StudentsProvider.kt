package com.example.databaselab

import android.content.*
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri

class StudentsProvider : ContentProvider() {

    private lateinit var dbHelper: DatabaseHandler

    companion object {
        const val PROVIDER_NAME = "com.example.databaselab.StudentsProvider"
        const val URL = "content://$PROVIDER_NAME/students"
        val CONTENT_URI = Uri.parse(URL)

        const val STUDENTS = 1
        const val STUDENT_ID = 2

        val uriMatcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(PROVIDER_NAME, "students", STUDENTS)
            addURI(PROVIDER_NAME, "students/#", STUDENT_ID)
        }
    }

    private lateinit var database: SQLiteDatabase

    override fun onCreate(): Boolean {
        dbHelper = context?.let { DatabaseHandler(it) } ?: return false
        database = dbHelper.writableDatabase
        return database != null
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        val qb = SQLiteQueryBuilder()
        qb.tables = DatabaseHandler.TABLE_STUDENTS

        when (uriMatcher.match(uri)) {
            STUDENTS -> {
                // Для запроса всех студентов
            }
            STUDENT_ID -> {
                qb.appendWhere("${DatabaseHandler.KEY_ID} = ${uri.pathSegments[1]}")
            }
            else -> throw IllegalArgumentException("Unknown URI $uri")
        }

        val cursor = qb.query(database, projection, selection, selectionArgs, null, null, sortOrder)
        cursor?.setNotificationUri(context?.contentResolver, uri)
        return cursor
    }

    override fun getType(uri: Uri): String {
        return when (uriMatcher.match(uri)) {
            STUDENTS -> "vnd.android.cursor.dir/vnd.example.students"
            STUDENT_ID -> "vnd.android.cursor.item/vnd.example.students"
            else -> throw IllegalArgumentException("Unsupported URI: $uri")
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri {
        val contentValues = values ?: throw IllegalArgumentException("Values cannot be null")

        val rowID = database.insert(DatabaseHandler.TABLE_STUDENTS, null, contentValues)

        if (rowID > 0) {
            val _uri = ContentUris.withAppendedId(CONTENT_URI, rowID)
            context?.contentResolver?.notifyChange(_uri, null)
            return _uri
        }
        throw SQLException("Failed to add a record into $uri")
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        var count = 0
        when (uriMatcher.match(uri)) {
            STUDENTS -> {
                count = database.delete(
                    DatabaseHandler.TABLE_STUDENTS,
                    selection,
                    selectionArgs
                )
            }
            STUDENT_ID -> {
                val id = uri.pathSegments[1]
                count = database.delete(
                    DatabaseHandler.TABLE_STUDENTS,
                    "${DatabaseHandler.KEY_ID} = ?",
                    arrayOf(id)
                )
            }
            else -> throw IllegalArgumentException("Unknown URI $uri")
        }

        context?.contentResolver?.notifyChange(uri, null)
        return count
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        val contentValues = values ?: throw IllegalArgumentException("Values cannot be null")

        var count = 0
        when (uriMatcher.match(uri)) {
            STUDENTS -> {
                count = database.update(
                    DatabaseHandler.TABLE_STUDENTS,
                    contentValues,
                    selection,
                    selectionArgs
                )
            }
            STUDENT_ID -> {
                val id = uri.pathSegments[1]
                count = database.update(
                    DatabaseHandler.TABLE_STUDENTS,
                    contentValues,
                    "${DatabaseHandler.KEY_ID} = ?",
                    arrayOf(id)
                )
            }
            else -> throw IllegalArgumentException("Unknown URI $uri")
        }

        context?.contentResolver?.notifyChange(uri, null)
        return count
    }
}