package com.example.databaselab

data class Value(
    var id: Long = 0,
    var value: String = ""
) {
    constructor(value: String) : this(0, value)
}