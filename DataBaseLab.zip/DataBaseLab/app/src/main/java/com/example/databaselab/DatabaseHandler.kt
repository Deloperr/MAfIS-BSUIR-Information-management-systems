package com.example.databaselab

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHandler(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_VERSION = 2
        private const val DATABASE_NAME = "studentsManager.db"
        const val TABLE_STUDENTS = "students"
        const val KEY_ID = "id"
        const val KEY_NAME = "name"
        const val KEY_AGE = "age"
        const val KEY_ADDRESS = "address"

        val ALL_COLUMNS = arrayOf(KEY_ID, KEY_NAME, KEY_AGE, KEY_ADDRESS)
    }

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_STUDENTS_TABLE = """
            CREATE TABLE $TABLE_STUDENTS (
                $KEY_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $KEY_NAME TEXT NOT NULL,
                $KEY_AGE INTEGER NOT NULL,
                $KEY_ADDRESS TEXT
            )
        """.trimIndent()
        db.execSQL(CREATE_STUDENTS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        when (oldVersion) {
            1 -> {
                db.execSQL("ALTER TABLE $TABLE_STUDENTS ADD COLUMN $KEY_ADDRESS TEXT")
            }
        }
    }

    fun addStudent(student: Student): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_NAME, student.name)
            put(KEY_AGE, student.age)
            put(KEY_ADDRESS, student.address)
        }

        val id = db.insert(TABLE_STUDENTS, null, values)
        db.close()
        return id
    }

    fun getStudent(id: Long): Student? {
        val db = this.readableDatabase
        val cursor: Cursor = db.query(
            TABLE_STUDENTS,
            ALL_COLUMNS,
            "$KEY_ID = ?",
            arrayOf(id.toString()),
            null, null, null, null
        )

        cursor.use {
            if (it.moveToFirst()) {
                return Student(
                    it.getLong(it.getColumnIndexOrThrow(KEY_ID)),
                    it.getString(it.getColumnIndexOrThrow(KEY_NAME)),
                    it.getInt(it.getColumnIndexOrThrow(KEY_AGE)),
                    it.getString(it.getColumnIndexOrThrow(KEY_ADDRESS))  // Читаем адрес
                )
            }
        }
        return null
    }

    fun getAllStudents(): List<Student> {
        val studentList = ArrayList<Student>()
        val selectQuery = "SELECT * FROM $TABLE_STUDENTS"
        val db = this.writableDatabase
        val cursor: Cursor = db.rawQuery(selectQuery, null)

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val student = Student(
                        it.getLong(it.getColumnIndexOrThrow(KEY_ID)),
                        it.getString(it.getColumnIndexOrThrow(KEY_NAME)),
                        it.getInt(it.getColumnIndexOrThrow(KEY_AGE)),
                        it.getString(it.getColumnIndexOrThrow(KEY_ADDRESS))
                    )
                    studentList.add(student)
                } while (it.moveToNext())
            }
        }
        return studentList
    }

    fun getStudentsOlderThan(age: Int): List<Student> {
        val studentList = ArrayList<Student>()
        val db = this.readableDatabase
        val cursor: Cursor = db.query(
            TABLE_STUDENTS,
            ALL_COLUMNS,
            "$KEY_AGE > ?",
            arrayOf(age.toString()),
            null, null, null, null
        )

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val student = Student(
                        it.getLong(it.getColumnIndexOrThrow(KEY_ID)),
                        it.getString(it.getColumnIndexOrThrow(KEY_NAME)),
                        it.getInt(it.getColumnIndexOrThrow(KEY_AGE)),
                        it.getString(it.getColumnIndexOrThrow(KEY_ADDRESS))
                    )
                    studentList.add(student)
                } while (it.moveToNext())
            }
        }
        return studentList
    }

    fun updateStudent(student: Student): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_NAME, student.name)
            put(KEY_AGE, student.age)
            put(KEY_ADDRESS, student.address)
        }

        return db.update(
            TABLE_STUDENTS,
            values,
            "$KEY_ID = ?",
            arrayOf(student.id.toString())
        )
    }

    fun deleteStudent(student: Student) {
        val db = this.writableDatabase
        db.delete(TABLE_STUDENTS, "$KEY_ID = ?", arrayOf(student.id.toString()))
        db.close()
    }

    fun deleteAllStudents() {
        val db = this.writableDatabase
        db.delete(TABLE_STUDENTS, null, null)
        db.close()
    }

    fun getStudentsCount(): Int {
        val countQuery = "SELECT * FROM $TABLE_STUDENTS"
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery(countQuery, null)
        val count = cursor.count
        cursor.close()
        return count
    }
}