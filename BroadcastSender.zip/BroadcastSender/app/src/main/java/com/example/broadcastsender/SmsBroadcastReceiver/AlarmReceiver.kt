package com.example.broadcastsender

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.Log
import android.widget.Toast

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("AlarmReceiver", "=== ALARM TRIGGERED ===")

        when (intent.action) {
            "com.example.ACTION_COLOR_CHANGE" -> {
                changeBackgroundColor(context)

                Toast.makeText(context, "🎨 Alarm: Screen color changed!",
                    Toast.LENGTH_LONG).show()
                Log.i("AlarmReceiver", "Screen color changed via alarm")
            }
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.d("AlarmReceiver", "Device booted, alarm should be re-set")
            }
        }
    }

    private fun changeBackgroundColor(context: Context) {
        try {
            val updateIntent = Intent("com.example.ACTION_UPDATE_COLOR").apply {
                putExtra("color", getRandomColor())
            }
            context.sendBroadcast(updateIntent)

        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Error changing color: ${e.message}")
        }
    }

    private fun getRandomColor(): Int {
        val colors = listOf(
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.CYAN, Color.MAGENTA, Color.parseColor("#FF6B35"),
            Color.parseColor("#6A0572"), Color.parseColor("#2A9D8F"),
            Color.parseColor("#E9C46A"), Color.parseColor("#F4A261"),
            Color.parseColor("#264653")
        )
        return colors.random()
    }
}