package com.example.broadcastsender

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.util.Log

class NextPageActivity : AppCompatActivity() {

    private lateinit var etPhoneNumber: EditText
    private lateinit var etMessage: EditText
    private lateinit var btnSendSmsBroadcast: Button
    private lateinit var btnSendMusicBroadcast: Button
    private lateinit var btnFinish: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next_page)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        etPhoneNumber = findViewById(R.id.etPhoneNumber)
        etMessage = findViewById(R.id.etMessage)
        btnSendSmsBroadcast = findViewById(R.id.btnSendSmsBroadcast)
        btnSendMusicBroadcast = findViewById(R.id.btnSendMusicBroadcast)
        btnFinish = findViewById(R.id.bfinish)
    }

    private fun setupClickListeners() {
        btnSendSmsBroadcast.setOnClickListener {
            sendSmsBroadcast()
        }

        btnSendMusicBroadcast.setOnClickListener {
            sendMusicBroadcast()
        }

        btnFinish.setOnClickListener {
            finish()
        }
    }

    private fun sendSmsBroadcast() {
        val phoneNumber = etPhoneNumber.text.toString().trim()
        val message = etMessage.text.toString().trim()

        if (phoneNumber.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Please enter phone number and message",
                Toast.LENGTH_LONG).show()
            return
        }

        val broadcastIntent = Intent("com.example.ACTION_SEND_SMS").apply {
            putExtra("phone_number", phoneNumber)
            putExtra("message", message)
            setPackage("com.example.smsreceiver")
        }
        sendBroadcast(broadcastIntent)

        Toast.makeText(this, "SMS Broadcast sent to SMS Receiver App", Toast.LENGTH_LONG).show()
        Log.d("BroadcastSender", "SMS broadcast sent to com.example.smsreceiver: $phoneNumber - $message")
    }

    private fun sendMusicBroadcast() {
        val broadcastIntent = Intent("com.example.ACTION_PLAY_MUSIC")
        sendBroadcast(broadcastIntent)

        Toast.makeText(this, "Music Broadcast sent", Toast.LENGTH_LONG).show()
        Log.d("BroadcastSender", "Music broadcast sent")
    }
}