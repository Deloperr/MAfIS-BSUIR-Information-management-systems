package com.example.broadcastsender

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import android.widget.Toast
import android.util.Log

class MusicService : Service() {

    private var myPlayer: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Toast.makeText(this, "Music Service Created", Toast.LENGTH_LONG).show()
        Log.d("MusicService", "Service Created - Oleg German greets You")

        try {
            myPlayer = MediaPlayer.create(this, R.raw.sun)
            myPlayer?.isLooping = false
        } catch (e: Exception) {
            Log.e("MusicService", "Error creating MediaPlayer: ${e.message}")
            Toast.makeText(this, "Music file not found, using demo mode", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Toast.makeText(this, "Music Service Started", Toast.LENGTH_LONG).show()
        Log.d("MusicService", "Service Started")

        Log.d("Tag Name", "Oleg German greets You")

        if (myPlayer != null) {
            myPlayer?.start()
        } else {
            Toast.makeText(this, "Music playback simulated", Toast.LENGTH_SHORT).show()
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Toast.makeText(this, "Music Service Stopped", Toast.LENGTH_LONG).show()
        Log.d("MusicService", "Service Stopped")

        myPlayer?.stop()
        myPlayer?.release()
        myPlayer = null
    }
}