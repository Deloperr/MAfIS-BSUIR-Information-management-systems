package com.example.broadcastsender

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var buttonStart: Button
    private lateinit var buttonStop: Button
    private lateinit var buttonNext: Button
    private lateinit var buttonSetAlarm: Button
    private lateinit var buttonCancelAlarm: Button
    private lateinit var etHours: EditText
    private lateinit var etMinutes: EditText
    private lateinit var tvAlarmStatus: TextView

    private lateinit var dynamicReceiver: BroadcastReceiver
    private lateinit var alarmManager: AlarmManager
    private lateinit var alarmPendingIntent: PendingIntent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupClickListeners()
        setupDynamicReceiver()
        initializeAlarmManager()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(dynamicReceiver)
    }

    private fun initializeViews() {
        buttonStart = findViewById(R.id.buttonStart)
        buttonStop = findViewById(R.id.buttonStop)
        buttonNext = findViewById(R.id.buttonNext)
        buttonSetAlarm = findViewById(R.id.buttonSetAlarm)
        buttonCancelAlarm = findViewById(R.id.buttonCancelAlarm)
        etHours = findViewById(R.id.etHours)
        etMinutes = findViewById(R.id.etMinutes)
        tvAlarmStatus = findViewById(R.id.tvAlarmStatus)
    }

    private fun setupClickListeners() {
        buttonStart.setOnClickListener {
            startService(Intent(this, MusicService::class.java))
            Toast.makeText(this, "Music Service Started", Toast.LENGTH_LONG).show()
            Log.d("BroadcastSender", "Music Service started - Oleg German greets You")
        }

        buttonStop.setOnClickListener {
            stopService(Intent(this, MusicService::class.java))
            Toast.makeText(this, "Music Service Stopped", Toast.LENGTH_LONG).show()
            Log.d("BroadcastSender", "Music Service stopped")
        }

        buttonNext.setOnClickListener {
            val intent = Intent(this, NextPageActivity::class.java)
            startActivity(intent)
        }

        buttonSetAlarm.setOnClickListener {
            setColorChangeAlarm()
        }

        buttonCancelAlarm.setOnClickListener {
            cancelColorChangeAlarm()
        }
    }

    private fun setupDynamicReceiver() {
        dynamicReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                Log.d("BroadcastSender", "=== DYNAMIC BROADCAST RECEIVED ===")
                Log.d("BroadcastSender", "Action: ${intent.action}")

                when (intent.action) {
                    "com.example.ACTION_SMS_STATUS" -> {
                        val status = intent.getStringExtra("status")
                        Toast.makeText(context, "SMS Status: $status", Toast.LENGTH_LONG).show()
                        Log.i("BroadcastSender", "SMS Status: $status")
                    }
                    "com.example.ACTION_UPDATE_COLOR" -> {
                        val color = intent.getIntExtra("color", Color.WHITE)
                        changeBackgroundColor(color)
                        Toast.makeText(context, "🎨 Alarm! Screen color changed!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction("com.example.ACTION_SMS_STATUS")
            addAction("com.example.ACTION_UPDATE_COLOR")
        }
        registerReceiver(dynamicReceiver, filter)

        Log.d("BroadcastSender", "Dynamic Broadcast Receiver registered")
    }

    private fun initializeAlarmManager() {
        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarmIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = "com.example.ACTION_COLOR_CHANGE"
        }
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        alarmPendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, flags)
    }

    private fun setColorChangeAlarm() {
        try {
            val hoursText = etHours.text.toString().trim()
            val minutesText = etMinutes.text.toString().trim()

            if (hoursText.isEmpty() || minutesText.isEmpty()) {
                Toast.makeText(this, "Please enter hours and minutes", Toast.LENGTH_LONG).show()
                return
            }

            val hours = hoursText.toInt()
            val minutes = minutesText.toInt()

            if (hours !in 0..23 || minutes !in 0..59) {
                Toast.makeText(this, "Invalid time: Hours (0-23), Minutes (0-59)", Toast.LENGTH_LONG).show()
                return
            }

            val calendar = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, hours)
                set(Calendar.MINUTE, minutes)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)

                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                    Log.d("Alarm", "Time passed today, setting for tomorrow")
                }
            }

            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                alarmPendingIntent
            )

            val alarmTime = String.format("%02d:%02d", hours, minutes)
            val alarmDate = if (calendar.get(Calendar.DAY_OF_YEAR) != Calendar.getInstance().get(Calendar.DAY_OF_YEAR)) {
                " (tomorrow)"
            } else {
                " (today)"
            }

            tvAlarmStatus.text = "Alarm set for: $alarmTime$alarmDate"
            Toast.makeText(this, "✅ Color change alarm set for $alarmTime$alarmDate", Toast.LENGTH_LONG).show()
            Log.d("Alarm", "Color change alarm set for $alarmTime$alarmDate")

        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_LONG).show()
            Log.e("Alarm", "Invalid number format: ${e.message}")
        } catch (e: Exception) {
            Toast.makeText(this, "Error setting alarm: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("Alarm", "Error: ${e.message}")

            showAlternativeSolution()
        }
    }

    private fun showAlternativeSolution() {
        Toast.makeText(this,
            "If alarm doesn't work, try setting time a few minutes from now for testing",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun cancelColorChangeAlarm() {
        try {
            alarmManager.cancel(alarmPendingIntent)
            tvAlarmStatus.text = "Alarm cancelled"
            Toast.makeText(this, "Color change alarm cancelled", Toast.LENGTH_LONG).show()
            Log.d("Alarm", "Color change alarm cancelled")
        } catch (e: Exception) {
            Toast.makeText(this, "Error cancelling alarm: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("Alarm", "Error cancelling: ${e.message}")
        }
    }

    private fun changeBackgroundColor(color: Int) {
        runOnUiThread {
            window.decorView.setBackgroundColor(color)
            Log.d("MainActivity", "Background color changed to: $color")

            val textColor = if (isColorDark(color)) Color.WHITE else Color.BLACK
            tvAlarmStatus.setTextColor(textColor)
        }
    }

    private fun isColorDark(color: Int): Boolean {
        val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return darkness >= 0.5
    }
}